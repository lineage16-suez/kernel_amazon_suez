### AnyKernel3 Ramdisk Mod Script

### AnyKernel setup
# begin properties
properties() { '
kernel.string=LineageOS 18.1 Suez DVFS controls kernel
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=suez
supported.versions=11
supported.patchlevels=
'; } # end properties

# Resolve TWRP's /boot mapping rather than probing the raw `boot` by-name
# partition, which is the amonet exploit partition on this device.
block=$(awk '$1 == "/boot" || $1 == "boot" { print $3; exit }' /etc/recovery.fstab 2>/dev/null);
[ -n "$block" ] || block=/nonexistent/anykernel-no-twrp-boot-mapping;
is_slot_device=0;
. tools/ak3-core.sh;

# Preserve and repack the existing ramdisk (including Magisk) while replacing
# only the compressed, DTB-appended kernel payload with Image.gz.
split_boot;
flash_boot;
